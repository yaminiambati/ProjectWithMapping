package com.capgemini.PromoRest.service;

import java.util.List;



import com.capgemini.PromoRest.model.Discount;

public interface DiscountService {

	public List<Discount> getAll();
	public void save(Discount discount);
	public void delete(Integer discountId) ;
	/*public void update(Pilot pilot);*/
	//public void update(Integer discountId);
	public void find(Integer discountId);
	//public Discount getOne(Integer fid);
}
