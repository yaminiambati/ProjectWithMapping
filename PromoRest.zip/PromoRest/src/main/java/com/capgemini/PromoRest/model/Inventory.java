package com.capgemini.PromoRest.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}) 
public class Inventory {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	
	/*@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="discountId")*/
	@OneToOne(targetEntity=Discount.class, mappedBy="inventory")
	private Discount discount;
	
	
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	/*public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
*/
	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
